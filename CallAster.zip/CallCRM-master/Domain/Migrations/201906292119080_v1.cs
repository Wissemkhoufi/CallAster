namespace Domain.Migrations
{
    using System.Data.Entity.Migrations;
    
    public partial class v1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "Clients",
                c => new
                    {
                        ClientID = c.Int(nullable: false, identity: true),
                        ContactStageID = c.Int(),
                        CompanyID = c.Int(),
                        EmployeeID = c.Int(),
                        FirstName = c.String(),
                        LastName = c.String(),
                        Gender = c.String(),
                        BirthDate = c.DateTime(nullable: false),
                        Position = c.String(),
                        PhoneNumber = c.String(),
                        Photo = c.String(),
                        CreationDate = c.DateTime(nullable: false),
                        ModificationDate = c.DateTime(),
                    })
                .PrimaryKey(t => t.ClientID)
                .ForeignKey("ContactStages", t => t.ContactStageID)
                .ForeignKey("Companies", t => t.CompanyID)
                .ForeignKey("Employees", t => t.EmployeeID)
                .Index(t => t.ContactStageID)
                .Index(t => t.CompanyID)
                .Index(t => t.EmployeeID);
            
            CreateTable(
                "ContactStages",
                c => new
                    {
                        ContactStageID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Color = c.String(),
                        Code = c.String(),
                        Description = c.String(),
                        Weight = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ContactStageID);
            
            CreateTable(
                "Companies",
                c => new
                    {
                        CompanyID = c.Int(nullable: false, identity: true),
                        ContactStageID = c.Int(),
                        Name = c.String(),
                        Description = c.String(),
                        Logo = c.String(),
                        CreationDate = c.DateTime(nullable: false),
                        ModificationDate = c.DateTime(),
                    })
                .PrimaryKey(t => t.CompanyID)
                .ForeignKey("ContactStages", t => t.ContactStageID)
                .Index(t => t.ContactStageID);
            
            CreateTable(
                "Employees",
                c => new
                    {
                        EmployeeID = c.Int(nullable: false, identity: true),
                        FirstName = c.String(),
                        LastName = c.String(),
                        Gender = c.String(),
                        Email = c.String(),
                        Position = c.String(),
                        Password = c.String(),
                        Solt = c.String(),
                        CreationDate = c.DateTime(nullable: false),
                        UserID = c.Guid(nullable: false),
                        AsteriskName = c.String(),
                    })
                .PrimaryKey(t => t.EmployeeID);
            
            CreateTable(
                "Events",
                c => new
                    {
                        EventID = c.Int(nullable: false, identity: true),
                        ClientID = c.Int(),
                        EventStatusID = c.Int(),
                        EventCategoryID = c.Int(nullable: false),
                        EmployeeID = c.Int(),
                        Inbound = c.Boolean(nullable: false),
                        IsComplete = c.Boolean(nullable: false),
                        Description = c.String(),
                        IsPlanned = c.Boolean(nullable: false),
                        PlannedDate = c.DateTime(),
                        CreationDate = c.DateTime(nullable: false),
                        ModificationDate = c.DateTime(),
                        CreatedBy = c.String(),
                        IsServedBy = c.Boolean(nullable: false),
                        AsteriskEventUniqueId = c.String(),
                    })
                .PrimaryKey(t => t.EventID)
                .ForeignKey("Clients", t => t.ClientID)
                .ForeignKey("EventStatus", t => t.EventStatusID)
                .ForeignKey("EventCategories", t => t.EventCategoryID, cascadeDelete: true)
                .ForeignKey("Employees", t => t.EmployeeID)
                .Index(t => t.ClientID)
                .Index(t => t.EventStatusID)
                .Index(t => t.EventCategoryID)
                .Index(t => t.EmployeeID);
            
            CreateTable(
                "EventStatus",
                c => new
                    {
                        EventStatusID = c.Int(nullable: false, identity: true),
                        EventCategoryID = c.Int(nullable: false),
                        Name = c.String(),
                        Code = c.String(),
                        Icon = c.String(),
                        Description = c.String(),
                    })
                .PrimaryKey(t => t.EventStatusID)
                .ForeignKey("EventCategories", t => t.EventCategoryID, cascadeDelete: true)
                .Index(t => t.EventCategoryID);
            
            CreateTable(
                "EventCategories",
                c => new
                    {
                        EventCategoryID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Code = c.String(),
                        IsTask = c.Boolean(nullable: false),
                        Icon = c.String(),
                        Description = c.String(),
                        IsSystem = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.EventCategoryID);
            
            CreateTable(
                "ContactFields",
                c => new
                    {
                        ContactFieldID = c.Int(nullable: false, identity: true),
                        ContactFieldTypeID = c.Int(nullable: false),
                        Value = c.String(),
                        RelateToID = c.Int(),
                    })
                .PrimaryKey(t => t.ContactFieldID)
                .ForeignKey("ContactFieldTypes", t => t.ContactFieldTypeID, cascadeDelete: true)
                .Index(t => t.ContactFieldTypeID);
            
            CreateTable(
                "ContactFieldTypes",
                c => new
                    {
                        ContactFieldTypeID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Lenght = c.Int(),
                    })
                .PrimaryKey(t => t.ContactFieldTypeID);
            
            CreateTable(
                "CustomFields",
                c => new
                    {
                        CustomFieldID = c.Int(nullable: false, identity: true),
                        CustomFieldTypeID = c.Int(nullable: false),
                        Value = c.String(),
                        RelateToID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.CustomFieldID)
                .ForeignKey("CustomFieldTypes", t => t.CustomFieldTypeID, cascadeDelete: true)
                .Index(t => t.CustomFieldTypeID);
            
            CreateTable(
                "CustomFieldTypes",
                c => new
                    {
                        CustomFieldTypeID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Lenght = c.Int(nullable: false),
                        AddTo = c.String(),
                    })
                .PrimaryKey(t => t.CustomFieldTypeID);
            
            CreateTable(
                "AsteriskEvents",
                c => new
                    {
                        AsteriskEventID = c.Int(nullable: false, identity: true),
                        Event = c.String(),
                        Channel = c.String(),
                        State = c.String(),
                        CallerIdName = c.String(),
                        CallerIdNum = c.String(),
                        UniqueId = c.String(),
                        IsServedBy = c.Boolean(nullable: false),
                        ReceivedTime = c.DateTime(nullable: false),
                        Destination = c.String(),
                        IsOutgoing = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.AsteriskEventID);
            
            CreateTable(
                "AsteriskIVRDefinitions",
                c => new
                    {
                        AsteriskIVRDefinitionID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Extention = c.String(),
                        CreationDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.AsteriskIVRDefinitionID);
            
            CreateTable(
                "AsteriskIVRSteps",
                c => new
                    {
                        AsteriskIVRStepID = c.Int(nullable: false, identity: true),
                        KeyPress = c.String(),
                        Action = c.String(),
                        Data = c.String(),
                        Submenu = c.Int(nullable: false),
                        Step = c.Int(nullable: false),
                        GoToStep = c.Int(),
                        AsteriskIVRDefinitionID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.AsteriskIVRStepID)
                .ForeignKey("AsteriskIVRDefinitions", t => t.AsteriskIVRDefinitionID, cascadeDelete: true)
                .Index(t => t.AsteriskIVRDefinitionID);
            
        }
        
        public override void Down()
        {
            DropIndex("AsteriskIVRSteps", new[] { "AsteriskIVRDefinitionID" });
            DropIndex("CustomFields", new[] { "CustomFieldTypeID" });
            DropIndex("ContactFields", new[] { "ContactFieldTypeID" });
            DropIndex("EventStatus", new[] { "EventCategoryID" });
            DropIndex("Events", new[] { "EmployeeID" });
            DropIndex("Events", new[] { "EventCategoryID" });
            DropIndex("Events", new[] { "EventStatusID" });
            DropIndex("Events", new[] { "ClientID" });
            DropIndex("Companies", new[] { "ContactStageID" });
            DropIndex("Clients", new[] { "EmployeeID" });
            DropIndex("Clients", new[] { "CompanyID" });
            DropIndex("Clients", new[] { "ContactStageID" });
            DropForeignKey("AsteriskIVRSteps", "AsteriskIVRDefinitionID", "AsteriskIVRDefinitions");
            DropForeignKey("CustomFields", "CustomFieldTypeID", "CustomFieldTypes");
            DropForeignKey("ContactFields", "ContactFieldTypeID", "ContactFieldTypes");
            DropForeignKey("EventStatus", "EventCategoryID", "EventCategories");
            DropForeignKey("Events", "EmployeeID", "Employees");
            DropForeignKey("Events", "EventCategoryID", "EventCategories");
            DropForeignKey("Events", "EventStatusID", "EventStatus");
            DropForeignKey("Events", "ClientID", "Clients");
            DropForeignKey("Companies", "ContactStageID", "ContactStages");
            DropForeignKey("Clients", "EmployeeID", "Employees");
            DropForeignKey("Clients", "CompanyID", "Companies");
            DropForeignKey("Clients", "ContactStageID", "ContactStages");
            DropTable("AsteriskIVRSteps");
            DropTable("AsteriskIVRDefinitions");
            DropTable("AsteriskEvents");
            DropTable("CustomFieldTypes");
            DropTable("CustomFields");
            DropTable("ContactFieldTypes");
            DropTable("ContactFields");
            DropTable("EventCategories");
            DropTable("EventStatus");
            DropTable("Events");
            DropTable("Employees");
            DropTable("Companies");
            DropTable("ContactStages");
            DropTable("Clients");
        }
    }
}
