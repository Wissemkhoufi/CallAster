using System;
using System.Collections.Generic;
using System.Text;

namespace Asterisk.NET.Manager.Action
{
	public abstract class ProxyAction : ManagerAction
	{
	}
}
