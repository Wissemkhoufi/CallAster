namespace Asterisk.NET.Manager.Event
{
	public class MeetmeEndEvent : AbstractMeetmeEvent
	{

		public MeetmeEndEvent(ManagerConnection source)
			: base(source)
		{
		}
	}
}